﻿namespace SW2URDF.URDF
{
    public static class ConfigVersion
    {
        public static readonly double DATA_CONTRACT_VERSION = 1.4;
    }
}