﻿
namespace SW2URDF.Test
{
    /// <summary>
    /// Todo(SIMINT-164) write tests to test existance of ROS files
    /// </summary>
    public class TestROSFIles : SW2URDFTest
    {
        public TestROSFIles(SWTestFixture fixture) : base(fixture)
        {
        }
    }
}
