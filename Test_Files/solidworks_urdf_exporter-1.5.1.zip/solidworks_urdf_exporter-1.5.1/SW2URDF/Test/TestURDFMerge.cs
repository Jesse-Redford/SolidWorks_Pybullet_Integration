﻿namespace SW2URDF.Test
{
    /// <summary>
    /// TODO(SIMINT-164) Implement tests covering public methods below
    /// public Link Merge(TreeView cadTree, URDFTreeCorrespondance correspondance)
    /// public void BuildCorrespondance(URDFTreeView existingTree, List<Link> loadedLinks, 
    ///     out List<Link> matchedLinks, out List<Link> unmatchedLinks)
    /// public Link GetCorrespondingLink(TreeViewItem item)
    /// </summary>
    public class TestURDFMerge : SW2URDFTest
    {
        public TestURDFMerge(SWTestFixture fixture) : base(fixture)
        {
        }
    }
}