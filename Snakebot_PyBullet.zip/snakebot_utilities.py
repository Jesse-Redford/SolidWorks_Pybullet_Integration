# snakebot_utilities

import pybullet
import pybullet_data

import keras
import time
import random
import keyboard
import itertools
import numpy as np
import collections
import math
import matplotlib.pyplot as plt
import pybullet_functions as jr

import VisualizeNN as VisNN
import ModVisualizeNN as ModVisNN



    
#-----------------------------------------------------------------
#             DQN Launch File / Functions                        #
#-----------------------------------------------------------------

    
def launch_DQN( model = None, a_dots=None, model_arch = None, training_time = 10, buffer_size = 10000,
                epsilion_initial = 1, batch_size = 32, learning_rate = .01, discountfactor = .9, update_frequency = 64,
                gravity = -10, timestep = 1./60, decision_interval=1,center_link_mass = None, outer_link_mass = None,  
                wheel_mass=None, rolling_friction = None, lateral_fricition = None,spinning_fricition = None,friction_anchor=None,
                wheel_restitution = None,joint_limits=np.pi/2):
                
    # Generate Action List
    actions = list(itertools.product(a_dots,a_dots))
    print('Number of Actions',len(actions))
    print('List of Actions (a_dots)',actions)
    
    # Generate Policy Rollout out figure
    policy_fig, step_vs_joints, step_vs_position, step_vs_reward, step_vs_loss = create_plots()
    
    # Create Empty list
    Total_Reward,Reward,Total_Loss,Loss = ([],[],[],[])
    
    JOINT_ONE,JOINT_TWO,STEP = ([],[],[])
    
    
    # Set up defuals for tracking cam
    tracking_cam = True
    viewing_timestep = timestep
                
    # initalize pybullet simulation enviroment,
    pybullet.connect(pybullet.GUI)
    pybullet.resetSimulation()
    pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
    
    # Load "floor", otherwise unfixed based will "fall through plane"
    pybullet.loadURDF("plane.urdf")
    pybullet.createCollisionShape(pybullet.GEOM_PLANE)
        
    # Define starting position and orientation for robot
    StartingOrientation = pybullet.getQuaternionFromEuler([0,0,0])
    StartingPosition = [1,1,.03] # x,y,z
    
    # Load robot URDF file created in solidworks
    robot = pybullet.loadURDF(r'C:\Users\Jesse\Desktop\SnakeBot_Simulator\Solidworks_Assembly\Snakebot_urdf.SLDASM\urdf\Snakebot_urdf.SLDASM.urdf',
                              StartingPosition,
                              StartingOrientation,
                              useFixedBase=0)
    jr.color_code_joints(robot)
    
    # Modify default robot model parameters 
    if center_link_mass != None:
        pybullet.changeDynamics(robot,linkIndex=-1,mass=center_link_mass) 
    if outer_link_mass != None:
        pybullet.changeDynamics(robot,linkIndex=0,mass=outer_link_mass)
        pybullet.changeDynamics(robot,linkIndex=3,mass=outer_link_mass)
    if wheel_mass != None:
        jr.add_wheels_mass(robot,wheel_mass=wheel_mass)
    if rolling_friction != None:
        jr.add_rolling_friction(robot,friction=rolling_friction)
    if lateral_fricition != None:
        jr.add_lateral_friction(robot,friction=lateral_fricition)
    if spinning_fricition != None:
        jr.add_spinning_friction(robot,friction=spinning_fricition)
    if friction_anchor != None: 
        jr.add_friction_anchor(robot,friction_anchor=friction_anchor)
    if wheel_restitution != None:
        jr.add_wheel_restitution(robot,wheel_restitution=wheel_restitution)
        
    # Initalize Physics Engine parameters (always after modifiying robot parameters)
    pybullet.setGravity(0, 0, gravity)
    pybullet.setTimeStep(timestep) 
    pybullet.setRealTimeSimulation(1) # 1 = True, 0 = False
    pybullet.setPhysicsEngineParameter(fixedTimeStep=timestep,
                                       numSolverIterations=1,
                                       useSplitImpulse =1,
                                       numSubSteps=1,
                                       enableConeFriction=1,
                                       collisionFilterMode =0)
    
    
    # Generated DQN model based on launch parameters 
    if model == None:
        Q_network,Target_network = generate_networks(actions,
                                                     layer1 = model_arch[0],L1_activation = model_arch[1],
                                                     layer2 = model_arch[2], L2_activation=model_arch[3],
                                                     learning_rate = learning_rate)
        save_network(Q_network,str(0)+'min')
        untrained_model = '0min.h5'
        anaylize_model(untrained_model)
        ModVisNN.DrawNN(untrained_model).draw() 
        
    # Load Model                        
    else:
        Q_network = keras.models.load_model(str(model)) # load a model and actions here
        Target_network = Q_network
        anaylize_model(model)
        #actions = [(-0.39269908169872414, -0.39269908169872414), (-0.39269908169872414, 0.0), (-0.39269908169872414, 0.39269908169872414),(0.0, -0.39269908169872414),  (0.0, 0.39269908169872414),  (0.39269908169872414, -0.39269908169872414),  (0.39269908169872414, 0.0),  (0.39269908169872414, 0.39269908169872414)] 
        
      
 
    
    

    # Set Target Weights 
    Target_network.set_weights(Q_network.get_weights())
    
    # Initialize Replay Buffer 
    D = collections.deque(maxlen=buffer_size)
    
    # define reference goal corridnate
    xg = 500

    # Initalize Counters
    i=0
    step = 0
    current_eps = epsilion_initial
    
    # Get current state of robot
    a1,a2,theta,xi_pos = jr.get_system_state(robot)
    state = a1,a2,theta
    
    # Begin DQN algorithm and Simulations
    while True:     
        if tracking_cam == True:
                position, orientation = pybullet.getBasePositionAndOrientation(robot)
                pybullet.resetDebugVisualizerCamera(cameraDistance = .1, cameraYaw = 0, cameraPitch = -95.0,cameraTargetPosition =[position[0],position[1],position[2]+1])
            
        
        # Expo Decay Epsilion
        current_eps = current_eps * Beta(epsilion_initial,.01,int((training_time*60)/decision_interval)) 
      
        epsilion = current_eps
        
        # get current xpos and state, then select action
        _,_,_,xi_pos = jr.get_system_state(robot)
        a1,a2,theta = state
        
        # select action
        action = get_action(Q_network, state, actions, epsilion )
        a1_dot,a2_dot = action
        
        # execute action
        for i in range(int(decision_interval/timestep)): # calculate number of iterations for decision interval
            if tracking_cam == True:
                position, orientation = pybullet.getBasePositionAndOrientation(robot)
                pybullet.resetDebugVisualizerCamera(cameraDistance = .1, cameraYaw = 0, cameraPitch = -95.0,cameraTargetPosition =[position[0],position[1],position[2]+1])
            
            # Check Boundries / Overide action if violates joint limits
            if a1 >= joint_limits and a1_dot > 0:
                a1_dot = 0
                #pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = joint_limits)
            if a1 <= -joint_limits and a1_dot < 0:
                #pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = -joint_limits)
                a1_dot = 0
            if a2 >= joint_limits and a2_dot > 0:
                a2_dot = 0
                #pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = joint_limits)
            if a2 <= -joint_limits and a2_dot < 0:
                a2_dot = 0
                #pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = -joint_limits)
            
           # pybullet.stepSimulation()
                
            # add position constraint not allow joint to rotate more than joint limit 
            
            # Execute action velosities
            pybullet.setJointMotorControl2(robot, 0, pybullet.VELOCITY_CONTROL,targetVelocity = a1_dot) #pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = a1 + (a1_dot*timestep))
            pybullet.stepSimulation()
            pybullet.setJointMotorControl2(robot, 3, pybullet.VELOCITY_CONTROL,targetVelocity = a2_dot) #pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = a2 + (a2_dot*timestep))
            pybullet.stepSimulation()
            time.sleep(viewing_timestep)
            
            # Update at each sim step
            a1,a2,theta,xf_pos = jr.get_system_state(robot)
    
        # Update state based on last recorded  
        newstate = a1,a2,theta
        
        # Compute reward
        if theta >= -np.pi/2 and theta <= np.pi/2:
            reward = ((xg-xi_pos) - (xg-xf_pos))*100 
        else:  
            reward = ((xg-xi_pos) - (xg-xf_pos))*100 -10

        # Add experence to replay buffer
        experince = state,action,newstate,reward
        D.append(experince)
    
        # Preform experience replay
        if step > batch_size:
            Q_network,replay_loss = experience_replay(Q_network, Target_network, D, learning_rate, discountfactor, batch_size, actions)
            Loss.append(replay_loss)
    
        # Update weights target network, reset counter
        if i > update_frequency:
            i=0
            Target_network.set_weights(Q_network.get_weights())
        i = i +1
    
        # Preform gradient decent step on current expereince
        Q_network,step_loss = experience_replay(Q_network, Target_network, D, learning_rate, discountfactor, batch_size, actions,experience = experince )
        
        # Save preformance metrics
        Reward.append(reward)
        Total_Loss.append(sum(Loss))
        Total_Reward.append(sum(Reward))
        
        JOINT_ONE.append(a1)
        JOINT_TWO.append(a2)
        STEP.append(step) 
        
        
        
        # update state / counter
        state = newstate
        step = step+1
        
        if ((decision_interval*step)/60) >= training_time:
            save_network(Q_network,str(training_time)+'min')
            anaylize_model(str(training_time)+'min'+'.h5')
            # save actions / model parameters
            pybullet.disconnect()
            
   
        # Check User Input
        if keyboard.is_pressed('t') and tracking_cam == False:
            tracking_cam = True
            time.sleep(.1)
            
        if keyboard.is_pressed('t') and tracking_cam == True:
            tracking_cam = False
            time.sleep(.1)
            
        if keyboard.is_pressed('up'):
            viewing_timestep = viewing_timestep + timestep 
            print('current view delay',viewing_timestep,'seconds')
        
        if keyboard.is_pressed('down'):
            if viewing_timestep > 0:
                viewing_timestep = viewing_timestep - timestep 
            else:
                viewing_timestep = 0
            print('current view delay',viewing_timestep,'seconds')
            
        if keyboard.is_pressed('q'):
            jr.get_system_state(robot,True)
            print('step',step)
            
        if keyboard.is_pressed('e'):
            print('current epsilion',epsilion)
          
        if keyboard.is_pressed('r'):
            print('reward',reward)
           
        if keyboard.is_pressed('s'):
            print('saving model')
            save_network(Q_network,str(step))
            
        if keyboard.is_pressed('l'):
            print('replay loss',replay_loss)
            
            
        if keyboard.is_pressed('a'):
            print('selected action',action)
    
        if keyboard.is_pressed('p'):
            position, orientation = pybullet.getBasePositionAndOrientation(robot)
            #step_vs_joints.plot(STEP,JOINT_ONE,color='red')
            #step_vs_joints.plot(STEP,JOINT_TWO,color='blue')
            step_vs_joints.scatter(step,a1,color='red',marker='>')
            step_vs_joints.scatter(step,a2,color='green',marker='<')
            step_vs_reward.scatter(step,Total_Reward[step-1],color='red')
            step_vs_position.scatter(position[0],position[1],color='black',marker='x')
            if step > batch_size:
                step_vs_loss.scatter(step,replay_loss,color='blue',marker='d')
                #step_vs_loss.scatter(step,Total_Loss[step-1],color='green')
            plt.pause(0.000001)
            eps_p = 0
            epsilion = eps_p
        else:
            epsilion = current_eps
        
    #plt.show() 
    policy_fig.show()
    pybullet.disconnect()
    return

def Beta(start = 1,end = .1,maxsteps = 100):
    return math.exp(math.log(end/start)/maxsteps)
    
    
def anaylize_model(model_name):
    model = keras.models.load_model(str(model_name))
    model_config = str(model.get_config())
    #print('model configuration', str(model.get_config()))
    model_shape = []
    weights = []
    biases = []
    model_shape.append(model.inputs[0][0].shape[0])
    i=0
    for layer in model.layers:
        model_shape.append(layer.output_shape[1])
        weights.append(np.array(np.asmatrix(model.layers[i].get_weights()[0])))
        biases.append(np.array(np.asmatrix(model.layers[i].get_weights()[1])))
        i += 1
    network = VisNN.DrawNN( model_shape, weights,biases, str(model_name),model_config) 
    network.draw()
    return
    
def get_action(network, state, actions, epsilion):
    state = (np.asarray(state).reshape(1, len(state)))
    Q = network.predict(state)
    if random.uniform(0, 1) > epsilion: # print('Argmax Action')
        Q_index = np.argmax(Q)
        action = actions[Q_index]
    else:
        Q_index = random.randint(0,len(Q[0])-1)
        action = actions[Q_index]
    # print('Q_index',Q_index = np.argmax(Q) or random.randint(0,len(Q[0])-1) , 'Action', action = actions[Q_index] , 'Q_value', Q_value = Q[0][Q_index])
    return action
    
def generate_networks(actions,layer1 = None, L1_activation = 'tanh',layer2 = None, L2_activation='relu',learning_rate = None ):
    Q_network = keras.Sequential()
    Q_network.add(keras.layers.Dense(layer1, input_dim = 3, activation=L1_activation,kernel_initializer='random_normal'))
    Q_network.add(keras.layers.Dense(layer2, activation=L2_activation,kernel_initializer='random_normal'))
    Q_network.add(keras.layers.Dense(output_dim = len(actions), activation='linear',kernel_initializer='random_normal'))
    Q_network.compile(loss='mse', optimizer=keras.optimizers.Adadelta(lr=learning_rate)) #RMSprop
    Target_network = Q_network
    return Q_network,Target_network
    
    
def experience_replay(Q_network, Target_network, D, learning_rate, discountfactor, batch_size, actions,experience = None):
    Loss = []
    if experience == None:
        # extract  a sequence minibatch
        #start_index = random.randint(0, len(D)-batch_size)
        #minibatch = collections.deque(itertools.islice(D, start_index, start_index+batch_size))
        
        minibatch = random.sample(D,batch_size)
        for i in range(len(minibatch)): # loop through all experiences currently in the memory buffer D
            state,action,newstate,reward = minibatch[i] # unpack s,a,s',r from expiernces 
            state = (np.asarray(state).reshape(1, len(state)))
            newstate = (np.asarray(newstate).reshape(1, len(newstate)))
            current_Qs = Q_network.predict(state) # get current estimate for state s, "contains all Q(s,A) outputs"
            action_index = actions.index(action) # determine the index of Q(s,a) in current_Qs list 
            current_Q = current_Qs[0][action_index] # get current estimate of Q(s,a)
            Q = current_Q
            target_Qs = Target_network.predict(newstate) # get target estimates for newstate s',"contains all Qhat(s',A) outputs"
            target_index = np.argmax(Target_network.predict(newstate)) # determine the index of maxQhat(s',a') 
            target_Q = target_Qs[0][target_index] # set target_Q equal to maxQhat(s',a')  <-- target Q_function
            current_Qs[0][action_index] = current_Q + learning_rate * (reward + discountfactor * target_Q - current_Q) # (reward + discountfactor * target_Q)
            updated_Qs = current_Qs # since only 1 value differs from the current network output for Q(s,A)               
            # preform graident decent "fit" the Q_network weight theta such that Q(s,a) = update_Q 
            loss = Q_network.train_on_batch(state, updated_Qs) #orginial 
            Loss.append(loss)
            #Q_network.fit(state, updated_Qs, epochs=1)
    
    # preform gradient decent on current experience
    else:
        
        state,action,newstate,reward = experience # unpack s,a,s',r from expiernces 
        state = (np.asarray(state).reshape(1, len(state)))
        newstate = (np.asarray(newstate).reshape(1, len(newstate)))
        current_Qs = Q_network.predict(state) # get current estimate for state s, "contains all Q(s,A) outputs"
        action_index = actions.index(action) # determine the index of Q(s,a) in current_Qs list 
        current_Q = current_Qs[0][action_index] # get current estimate of Q(s,a)
        Q = current_Q
        target_Qs = Target_network.predict(newstate) # get target estimates for newstate s',"contains all Qhat(s',A) outputs"
        target_index = np.argmax(Target_network.predict(newstate)) # determine the index of maxQhat(s',a') 
        target_Q = target_Qs[0][target_index] # set target_Q equal to maxQhat(s',a')  <-- target Q_function
        current_Qs[0][action_index] = current_Q + learning_rate * (reward + discountfactor * target_Q - current_Q) # (reward + discountfactor * target_Q)
        updated_Qs = current_Qs # since only 1 value differs from the current network output for Q(s,A)               
        # preform graident decent "fit" the Q_network weight theta such that Q(s,a) = update_Q 
        loss = Q_network.train_on_batch(state, updated_Qs) #orginial 
        #Q_network.fit(state, updated_Qs, epochs=1)
        Loss.append(loss)
    #print('loss',sum(Loss))
    return(Q_network,sum(Loss))
    

def save_network(Q_network,model_name):
    print('Network saved as:' + model_name)
    Q_network.save(model_name +'.h5')
    print('done saving')
    return()
    
def create_plots():
    policy_fig = plt.figure(figsize=(10, 10))
    step_vs_joints = policy_fig.add_subplot(221)
    step_vs_joints.set_title('Sim step vs Joint Angles')
    step_vs_joints.set_xlabel('Simulation Step')
    step_vs_joints.set_ylabel('Joint Angles')
    
    step_vs_position = policy_fig.add_subplot(222)
    step_vs_position.set_title('Sim step vs position')
    step_vs_position.set_xlabel('X-pos')
    step_vs_position.set_ylabel('Y-pos')
    
    step_vs_reward = policy_fig.add_subplot(223)
    step_vs_reward.set_title('Sim step vs reward')
    step_vs_reward.set_xlabel('Simulation Step')
    step_vs_reward.set_ylabel('Reward')
    
    step_vs_loss = policy_fig.add_subplot(224)
    step_vs_loss.set_title('Sim step vs loss')
    step_vs_loss.set_xlabel('Simulation Step')
    step_vs_loss.set_ylabel('Loss')
    
    return policy_fig, step_vs_joints, step_vs_position, step_vs_reward, step_vs_loss
    
    

#-----------------------------------------------------------------
#             Interactive Launch File / Functions                #
#-----------------------------------------------------------------

def launch_interactive(tracking_cam = False,control_type = 'V',
                    center_link_mass = None, outer_link_mass = None, wheels_mass = None,
                    gravity = None, rolling_friction = None, lateral_fricition = None,spinning_fricition = None):
                    
    tracking_cam = False
    control_type = 'V'
    
    pybullet.connect(pybullet.GUI)
    pybullet.resetSimulation()
    pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
    pybullet.setPhysicsEngineParameter(collisionFilterMode =0)
    
    # Load "floor", otherwise unfixed based will "fall through plane"
    planeID = pybullet.loadURDF("plane.urdf")
    #pybullet.createCollisionShape(pybullet.GEOM_PLANE)
    
    # Define starting position and orientation
    StartingOrientation = pybullet.getQuaternionFromEuler([0,0,0])
    StartingPosition = [0,0,.03]
    
    # Load robot URDF file created in solidworks
    robot = pybullet.loadURDF(r'C:\Users\Jesse\Desktop\SnakeBot_Simulator\Solidworks_Assembly\Snakebot_urdf.SLDASM\urdf\Snakebot_urdf.SLDASM.urdf',StartingPosition,StartingOrientation,useFixedBase=0)
    
    jr.get_link_info(robot)
    jr.get_joint_info(robot)
    
    if rolling_friction != None:
        jr.add_rolling_friction(robot,friction=rolling_friction)
    if lateral_fricition != None:
        jr.add_lateral_friction(robot,friction=lateral_fricition)
    if spinning_fricition != None:
        jr.add_spinning_friction(robot,friction=spinning_fricition)
    if center_link_mass != None:
        pybullet.changeDynamics(robot,linkIndex=-1,mass=center_link_mass) #100
    if outer_link_mass != None:
        pybullet.changeDynamics(robot,linkIndex=0,mass=outer_link_mass)
        pybullet.changeDynamics(robot,linkIndex=3,mass=outer_link_mass)
    if wheels_mass != None:
        pybullet.changeDynamics(robot,linkIndex=1,mass=wheels_mass) #100
        pybullet.changeDynamics(robot,linkIndex=2,mass=wheels_mass)
        pybullet.changeDynamics(robot,linkIndex=4,mass=wheels_mass)
        pybullet.changeDynamics(robot,linkIndex=5,mass=wheels_mass) #100
        pybullet.changeDynamics(robot,linkIndex=6,mass=wheels_mass)
        pybullet.changeDynamics(robot,linkIndex=7,mass=wheels_mass)
    if gravity == None:
        gravity = -9.81
    
    
    jr.color_code_joints(robot)
    
    
    # Set up simulation parameters
    pybullet.setGravity(0, 0, gravity) #-9.81
    pybullet.setTimeStep(0.01) #0.01
    pybullet.setRealTimeSimulation(0)

  
    
    while True:
               
        if tracking_cam == True:
            position, orientation = pybullet.getBasePositionAndOrientation(robot)
            pybullet.resetDebugVisualizerCamera(cameraDistance = .1, cameraYaw = 0, cameraPitch = -95.0,cameraTargetPosition =[position[0],position[1],position[2]+1])
    
        if keyboard.is_pressed('left') and control_type =='P':
            head_joint_info = pybullet.getJointState(robot,0)
            tail_joint_info = pybullet.getJointState(robot,3)
            pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = head_joint_info[0] + .3)
            pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = tail_joint_info[0] +.45)
            pybullet.stepSimulation()
            time.sleep(.01)
        
        if keyboard.is_pressed('right') and control_type =='P':
            head_joint_info = pybullet.getJointState(robot,0)
            tail_joint_info = pybullet.getJointState(robot,3)
            pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = head_joint_info[0] - .35)
            pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = tail_joint_info[0] -.45)
            pybullet.stepSimulation()
            time.sleep(.01)
            
        if keyboard.is_pressed('left') and control_type =='V':
            pybullet.setJointMotorControl2(robot, 0, pybullet.VELOCITY_CONTROL,targetVelocity = 5)
            pybullet.setJointMotorControl2(robot, 3, pybullet.VELOCITY_CONTROL,targetVelocity = 5)
            pybullet.stepSimulation()
            time.sleep(.01)
            
        if keyboard.is_pressed('right') and control_type =='V':
            pybullet.setJointMotorControl2(robot, 0, pybullet.VELOCITY_CONTROL,targetVelocity = -5)
            pybullet.setJointMotorControl2(robot, 3, pybullet.VELOCITY_CONTROL,targetVelocity = -5)
            pybullet.stepSimulation()
            time.sleep(.01)
            
        
        if keyboard.is_pressed('c'):
            jr.get_contact_points()
            time.sleep(.1)
        
        
        if keyboard.is_pressed('q'):
            jr.get_system_state(robot,True)
            time.sleep(.1)
            
        if keyboard.is_pressed('r'):
            pybullet.setJointMotorControl2(robot, 0, pybullet.POSITION_CONTROL,targetPosition = 0)
            pybullet.setJointMotorControl2(robot, 3, pybullet.POSITION_CONTROL,targetPosition = 0)
            pybullet.stepSimulation()
            time.sleep(.01)
            
        if keyboard.is_pressed('P') and control_type == 'V':
            control_type = 'P'
            time.sleep(.1)
            
        if keyboard.is_pressed('P') and control_type == 'P':
            control_type = 'V'
            time.sleep(.1)
            
        if keyboard.is_pressed('t') and tracking_cam == False:
            tracking_cam = True
            time.sleep(.1)
            
        if keyboard.is_pressed('t') and tracking_cam == True:
            tracking_cam = False
            time.sleep(.1)
            
    pybullet.disconnect()

    
    return



def user_controls():
    return
    
