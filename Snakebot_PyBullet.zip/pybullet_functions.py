import pybullet
import pybullet_data
import math
import numpy as np


def get_joint_info(robot):
    print('-------------------------------------------------------------------' )
    print('|               Description of Robots Joints                      |')
    print('-------------------------------------------------------------------' )
    print('The system has', pybullet.getNumJoints(robot), 'joints')
    num_joints = pybullet.getNumJoints(robot)
    for i in range(num_joints):
        joint_info = pybullet.getJointInfo(robot, i)
        print('------------------------------------------------------------')
        print("Joint index: {}".format(joint_info[0]))
        print("Joint name: {}".format(joint_info[1]))
        print("Joint type: {}".format(joint_info[2]))
        print("First position index: {}".format(joint_info[3]))
        print("First velocity index: {}".format(joint_info[4]))
        print("flags: {}".format(joint_info[5]))
        print("Joint damping value: {}".format(joint_info[6]))
        print("Joint friction value: {}".format(joint_info[7]))
        print("Joint positional lower limit: {}".format(joint_info[8]))
        print("Joint positional upper limit: {}".format(joint_info[9]))
        print("Joint max force: {}".format(joint_info[10]))
        print("Joint max velocity {}".format(joint_info[11]))
        print("Name of link: {}".format(joint_info[12]))
        print("Joint axis in local frame: {}".format(joint_info[13]))
        print("Joint position in parent frame: {}".format(joint_info[14]))
        print("Joint orientation in parent frame: {}".format(joint_info[15]))
        print("Parent link index: {}".format(joint_info[16]))
    if i == num_joints-1:
        print('------------------------------------------------------------')
    return

def get_link_info(robot):
    
    print('-------------------------------------------------------------------' )
    print('|               Description of Robots Links                        |')
    print('-------------------------------------------------------------------' )

    num_joints = pybullet.getNumJoints(robot)
    
    for i in range(num_joints):
        
        joint_info = pybullet.getJointInfo(robot, i)
        link_state_list = pybullet.getLinkState(robot, i)
        
        print('--------------------------------------------------------------')
        print("Name of link: {}".format(joint_info[12]))
        print("Link position (center of mass):",tuple([float("{0:.3f}".format(n)) for n in link_state_list[0]]) )
        print("Link orientation (center of mass):",tuple([float("{0:.3f}".format(n)) for n in link_state_list[1]]) )
        print("Local position offset of inertial frame:",tuple([float("{0:.3f}".format(n)) for n in link_state_list[2]]) )
        print("Local orientation offset of inertial frame:",tuple([float("{0:.3f}".format(n)) for n in link_state_list[3]]) )
        print("Link frame position:",tuple([float("{0:.3f}".format(n)) for n in link_state_list[4]]) )
        print("Link frame orientation:",tuple([float("{0:.3f}".format(n)) for n in link_state_list[5]]) )
    print('------------------------------------------------------------------')
    
    """
        print("Name of link: {}".format(joint_info[12]))
        print("Link position (center of mass): {}".format(link_state_list[0]))
        print("Link orientation (center of mass): {}".format(link_state_list[1]))
        print("Local position offset of inertial frame: {}".format(link_state_list[2]))
        print("Local orientation offset of inertial frame: {}".format(link_state_list[3]))
        print("Link frame position: {}".format(link_state_list[4]))
        print("Link frame orientation: {}".format(link_state_list[5]))
    """
        
    return
    
def create_joint_position_controller(robot,joint_index=0,lower_limit=-3.14,upper_limit=3.14,inital_position=0):
    joint_info = pybullet.getJointInfo(robot, joint_index)
    joint_parameters = pybullet.addUserDebugParameter(paramName=str(joint_info[1])+'PC', rangeMin=lower_limit, rangeMax =upper_limit, startValue=inital_position)
    # pass the returned array to activate_position_contoller in the main loop of your script
    return [ joint_index,joint_parameters]
    
def activate_position_controller(robot,joint_parameters):
    joint_index = joint_parameters[0]
    angle = joint_parameters[1]
    user_angle = pybullet.readUserDebugParameter(angle)
    pybullet.setJointMotorControl2(robot, joint_index, pybullet.POSITION_CONTROL,targetPosition= user_angle)
    joint_info = pybullet.getJointState(robot,joint_index)
    joint_position = joint_info[0] 
    joint_velosity = joint_info[1]
    return joint_position,joint_velosity
    
def create_joint_velocity_controller(robot,joint_index=0,lower_limit=-10,upper_limit=10,inital_velosity=0):
    joint_info = pybullet.getJointInfo(robot, joint_index) # get name of joint, to create on screen label
    joint_parameters = pybullet.addUserDebugParameter(paramName=str(joint_info[1])+'VC', rangeMin=lower_limit, rangeMax =upper_limit, startValue=inital_velosity)
    # pass the returned array to activate_position_contoller in the main loop of your script
    return [ joint_index,joint_parameters]
    
def activate_velocity_controller(robot,joint_parameters):
    joint_index = joint_parameters[0]
    velosity = joint_parameters[1]
    user_velocity = pybullet.readUserDebugParameter(velosity)
    pybullet.setJointMotorControl2(robot, joint_index, pybullet.VELOCITY_CONTROL,targetVelocity= user_velocity)
    joint_info = pybullet.getJointState(robot,joint_index)
    joint_position = joint_info[0] 
    joint_velosity = joint_info[1]
    return joint_position,joint_velosity
    
    
def quat_to_euler(q):
    qx,qy,qz,qw = q
    """     
    # Conversion with angles between -pi/2 and pi/2
    ex =  np.arctan( (2*(qx*qy + qz*qw)) / (1-2*(qy**2 + qz**2)) ) 
    ey =  np.arcsin( 2*(qx*qz - qw*qy) )                            
    ez = np.arctan( (2*(qx*qw+qy*qz)) / (1-2*(qz**2 + qw**2)) ) 
    """
    # Conversion with angles between (-pi,pi). heading = ex, CW=neg, CCW=pos
    ex =  np.arctan2( (2*(qx*qy + qz*qw)) , (1-2*(qy**2 + qz**2)) )   
    ey =  np.arcsin( 2*(qx*qz - qw*qy) )
    ez = np.arctan2( (2*(qx*qw+qy*qz)) , (1-2*(qz**2 + qw**2)) )    
    E = ex,ey,ez
    return E
    

def get_system_state(robot, display = False):
    position, orientation = pybullet.getBasePositionAndOrientation(robot)
    joint1_info = pybullet.getJointState(robot,0)
    joint2_info = pybullet.getJointState(robot,3)
    E = quat_to_euler(orientation)
    

    
    # print("Center robot Position x(red),y(green),z(blue): {}".format(position))
    if display == True:
        print('---------------' )
        print('| System State |')
        print('---------------' )
        
        print('x: {0:.3f}'.format(position[0]))
        print('y: {0:.3f}'.format(position[1]))
        print('z: {0:.3f}'.format(position[2]))
        print('theta: {0:.3f}'.format(E[0])) # relative heading center link
   
        print('a1:{0:.3f}'.format(joint1_info[0]))
        print('a2:{0:.3f}'.format(joint2_info[0]))
    
        print('a1_dot:{0:.3f}'.format(joint1_info[1]))
        print('a2_dot:{0:.3f}'.format(joint2_info[1]))

    #return position[0],position[1],E[0]
    theta = E[0]
    a1 = joint1_info[0]
    a2 = joint2_info[0]
    x_pos = position[0]  
    return a1,a2,theta,x_pos
    

def get_contact_points():
    
   Contact_Info = pybullet.getContactPoints()
   print('---------------------------------------------------------')
   print('| There are:',len(Contact_Info),'contact points          |')
   print('---------------------------------------------------------')
   for i in range(len(Contact_Info)):
        Point = Contact_Info[i]
        print("Contact Point: {}".format(i))
        print("ContactFlag: {}".format(Point[0]))
        print("bodyUniqueIdA: {}".format(Point[1]))
        print("bodyUniqueIdB: {}".format(Point[2]))
        print("linkIndexA: {}".format(Point[3]))
        print("linkIndexB: {}".format(Point[4]))
        print("positionOnA:",tuple([float("{0:.3f}".format(n)) for n in Point[5]]) )
        print("positionOnB:",tuple([float("{0:.3f}".format(n)) for n in Point[6]]) )
        print("contactNormalOnB:",tuple([float("{0:.3f}".format(n)) for n in Point[7]]) )
        print("contactDistance: {0:.3f}".format(Point[8]))
        print("normalForce: {0:.3f}".format(Point[9]))
        print("lateralFriction1: {0:.3f}".format(Point[10]))
        print("lateralFrictionDir1",tuple([float("{0:.3f}".format(n)) for n in Point[11]]) )
        print("lateralFriction2: {0:.3f}".format(Point[12]))
        print("lateralFrictionDir2",tuple([float("{0:.3f}".format(n)) for n in Point[13]]) )
        print('--------------------------------------------------')
        
   return 

def add_rolling_friction(robot,friction=0):
    pybullet.changeDynamics(robot,1,rollingFriction=friction) # HLW
    pybullet.changeDynamics(robot,2,rollingFriction=friction) # HRW
    pybullet.changeDynamics(robot,4,rollingFriction=friction) # TLW
    pybullet.changeDynamics(robot,5,rollingFriction=friction) # TRW
    pybullet.changeDynamics(robot,6,rollingFriction=friction) # CLW
    pybullet.changeDynamics(robot,7,rollingFriction=friction) # CRW
    return 
    
def add_spinning_friction(robot,friction=0):
    pybullet.changeDynamics(robot,1,spinningFriction=friction)
    pybullet.changeDynamics(robot,2,spinningFriction=friction)
    pybullet.changeDynamics(robot,4,spinningFriction=friction)
    pybullet.changeDynamics(robot,5,spinningFriction=friction)
    pybullet.changeDynamics(robot,6,spinningFriction=friction)
    pybullet.changeDynamics(robot,7,spinningFriction=friction)
    return 
    
def add_lateral_friction(robot,friction=0):
    pybullet.changeDynamics(robot,1,lateralFriction=friction)
    pybullet.changeDynamics(robot,2,lateralFriction=friction)
    pybullet.changeDynamics(robot,4,lateralFriction=friction)
    pybullet.changeDynamics(robot,5,lateralFriction=friction)
    pybullet.changeDynamics(robot,6,lateralFriction=friction)
    pybullet.changeDynamics(robot,7,lateralFriction=friction)
    return 
    
def add_wheel_restitution(robot,wheel_restitution=0):
    pybullet.changeDynamics(robot,linkIndex=1,restitution = wheel_restitution)
    pybullet.changeDynamics(robot,linkIndex=2,restitution = wheel_restitution)
    pybullet.changeDynamics(robot,linkIndex=4,restitution = wheel_restitution)
    pybullet.changeDynamics(robot,linkIndex=5,restitution = wheel_restitution)
    pybullet.changeDynamics(robot,linkIndex=6,restitution = wheel_restitution)
    pybullet.changeDynamics(robot,linkIndex=7,restitution = wheel_restitution)
    return 
    
def add_wheels_mass(robot,wheel_mass=0):
    pybullet.changeDynamics(robot,linkIndex=1,mass=wheel_mass) #100
    pybullet.changeDynamics(robot,linkIndex=2,mass=wheel_mass)
    pybullet.changeDynamics(robot,linkIndex=4,mass=wheel_mass)
    pybullet.changeDynamics(robot,linkIndex=5,mass=wheel_mass) #100
    pybullet.changeDynamics(robot,linkIndex=6,mass=wheel_mass)
    pybullet.changeDynamics(robot,linkIndex=7,mass=wheel_mass)
    return 
    
def add_friction_anchor(robot,friction_anchor=True):
    pybullet.changeDynamics(robot,linkIndex=1,frictionAnchor = friction_anchor) #100
    pybullet.changeDynamics(robot,linkIndex=2,frictionAnchor = friction_anchor)
    pybullet.changeDynamics(robot,linkIndex=4,frictionAnchor = friction_anchor)
    pybullet.changeDynamics(robot,linkIndex=5,frictionAnchor = friction_anchor) #100
    pybullet.changeDynamics(robot,linkIndex=6,frictionAnchor = friction_anchor)
    pybullet.changeDynamics(robot,linkIndex=7,frictionAnchor = friction_anchor)
    return 
    
def color_code_joints(robot):
    #change color of links
    pybullet.changeVisualShape(objectUniqueId = robot, linkIndex = -1, rgbaColor = [0,0,0,1])
    pybullet.changeVisualShape(objectUniqueId = robot, linkIndex = 0, rgbaColor = [1,0,0,1])
    pybullet.changeVisualShape(objectUniqueId = robot, linkIndex = 3, rgbaColor = [0,1,0,2])
    return


    
"""
def get_joint_info(robot):
    print('-------------------------------------------------------------------' )
    print('|               Description of Robots Joints                      |')
    print('-------------------------------------------------------------------' )
    print('The system has', pybullet.getNumJoints(robot), 'joints')
    num_joints = pybullet.getNumJoints(robot)
    for i in range(num_joints):
        joint_info = pybullet.getJointInfo(robot, i)
        print('------------------------------------------------------------')
        print("Joint index: {}".format(joint_info[0]))
        print("Joint name: {}".format(joint_info[1]))
        print("Joint type: {}".format(joint_info[2]))
        print("First position index: {}".format(joint_info[3]))
        print("First velocity index: {}".format(joint_info[4]))
        print("flags: {}".format(joint_info[5]))
        print("Joint damping value: {}".format(joint_info[6]))
        print("Joint friction value: {}".format(joint_info[7]))
        print("Joint positional lower limit: {}".format(joint_info[8]))
        print("Joint positional upper limit: {}".format(joint_info[9]))
        print("Joint max force: {}".format(joint_info[10]))
        print("Joint max velocity {}".format(joint_info[11]))
        print("Name of link: {}".format(joint_info[12]))
        print("Joint axis in local frame: {}".format(joint_info[13]))
        print("Joint position in parent frame: {}".format(joint_info[14]))
        print("Joint orientation in parent frame: {}".format(joint_info[15]))
        print("Parent link index: {}".format(joint_info[16]))
    if i == num_joints-1:
        print('------------------------------------------------------------')
    return

def get_link_info(robot):
    print('-------------------------------------------------------------------' )
    print('|               Description of Robots Links                        |')
    print('-------------------------------------------------------------------' )
    num_joints = pybullet.getNumJoints(robot)
    for i in range(num_joints):
        joint_info = pybullet.getJointInfo(robot, i)
        link_state_list = pybullet.getLinkState(robot, i)
        print('--------------------------------------------------------------')
        print("Name of link: {}".format(joint_info[12]))
        print("Link position (center of mass): {}".format(link_state_list[0]))
        print("Link orientation (center of mass): {}".format(link_state_list[1]))
        print("Local position offset of inertial frame: {}".format(link_state_list[2]))
        print("Local orientation offset of inertial frame: {}".format(link_state_list[3]))
        print("Link frame position: {}".format(link_state_list[4]))
        print("Link frame orientation: {}".format(link_state_list[5]))
    print('------------------------------------------------------------------')
    return
    
def create_joint_position_controller(joint_index=0,lower_limit=-3.14,upper_limit=3.14,inital_position=0):
    joint_info = pybullet.getJointInfo(robot, joint_index)
    joint_parameters = pybullet.addUserDebugParameter(paramName=str(joint_info[1])+'PC', rangeMin=lower_limit, rangeMax =upper_limit, startValue=inital_position)
    # pass the returned array to activate_position_contoller in the main loop of your script
    return [ joint_index,joint_parameters]
    
def activate_position_controller(joint_parameters):
    joint_index = joint_parameters[0]
    angle = joint_parameters[1]
    user_angle = pybullet.readUserDebugParameter(angle)
    pybullet.setJointMotorControl2(robot, joint_index, pybullet.POSITION_CONTROL,targetPosition= user_angle)
    joint_info = pybullet.getJointState(robot,joint_index)
    joint_position = joint_info[0] 
    joint_velosity = joint_info[1]
    return joint_position,joint_velosity


def get_system_state(robot):
    position, orientation = pybullet.getBasePositionAndOrientation(robot)
    # print("Center robot Position x(red),y(green),z(blue): {}".format(position))
    print('-------- System State --------------')
    print('x: {}'.format(position[0]))
    print('y: {}'.format(position[1]))
    print('theta: {}'.format(orientation[0])) # convert from quternion to euler
    print('a1:{}'.format(joint_info[1]))
    print('a2:{}'.format(joint_info[0]))
    return


#linkWorldPosition = pybullet.getLinkState(robot,link_index,computeLinkVelocity =1,computeForwardKinematics=1)

    
"""    