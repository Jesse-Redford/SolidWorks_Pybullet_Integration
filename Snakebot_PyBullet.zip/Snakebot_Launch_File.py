# Snakebot Launch File

import snakebot_utilities as SB
import numpy as np

"""
---------------------------------------------
            GENERAL NOTES                   |
---------------------------------------------
Arrows point in postive direction           |
x-axis (red)                                |
y-axis (green)                              |
z-axis (blue)                               |
                                            |
Head link (Red) "aligned with x-axis"       |
Tail Link (Green)                           |
                                            |
Starting orientation (theta,a1,a2) = 0      |
Starting Position x,y,z = 0,0,0             |
                                            |
Joint Angle Sign Convention                 |
\_/ = -a1, -a2                              |
/ \ = +a1, +a2                              |
                                            |
Heading Sign Convention                     |
CCW = +theta                                |
CC = -theta                                 |
                                            |
---------------------------------------------
|         INTERACTIVE INSTRUCTIONS          |
---------------------------------------------
use left/right arrow keys to control joints |
press hold r to rest joints to 0,0          |
toggle t for auto tracking / world view     |
toggle p for position / velocity control    |
press q to get x,y,theta,a1,a2,a1dot,a2dot  |
press c to  list of current contact points  |
---------------------------------------------
|         DQN INSTRUCTIONS                  |
---------------------------------------------
toggle t for auto tracking / world view     |
press up to slow down viewing               |
press down to speed up viewing              |
press q to get system state / step          |
press e to get current value of epsilion    |
press r to get current reward               |
press l to get current loss                 |
press a to get action                       |
press p to temporialy set eps to 0          |
press s to save network file                |
---------------------------------------------

# run default paramters
SB.launch_interactive() 
            
# run w/modified paramters                 
SB.launch_interactive(center_link_mass = 100, 
                       outer_link_mass = 100, 
                       wheels_mass = None,
                       gravity = -10, 
                       rolling_friction = 20, 
                       lateral_fricition = 20,
                       spinning_fricition = None)
"""

# Create List of Velosities for each Joint
a_dots =[-np.pi,-np.pi/2,-np.pi/4,-np.pi/6,0,np.pi/6,np.pi/4,np.pi/2,np.pi]   
#a_dots =[-np.pi/2,-np.pi/4,-np.pi/6,0,np.pi/6,np.pi/4,np.pi/2] 
# Load jacks model and actions
#model,actions = SB.load_simulated_model('50th_episode_model.json','50th_episode_weights.h5')  #model,weights
 

#a_dots =[-np.pi/2,-np.pi/4,-np.pi/6,0,np.pi/6,np.pi/4,np.pi/2] 
                                                   # Suggested Parameters 
SB.launch_DQN(model =None, # 'jacks_40th_episode_model.h5',                        # r'C:\Users\Jesse\Desktop\SnakeBot_Simulator\10387.h5',
              a_dots=a_dots,                       # [-np.pi,-np.pi/2,-np.pi/4,-np.pi/6,0,np.pi/6,np.pi/4,np.pi/2,np.pi]
              model_arch = [16,'tanh',16,'tanh'],  # [16,'tanh',16,'tanh']
              training_time = 60,                  # Goal 30min
              buffer_size = 100000,                # Should record all experiences , (training_time*60)/decision_interval
              epsilion_initial = 3,                # 3 because expo decay 
              batch_size = 64,                     # 32
              learning_rate = .01,                 # .01
              discountfactor = .9,                 # .9
              update_frequency = 64,               # 64
              gravity = -10,                       # -10
              timestep = 1./60.,                   # 1./60. sec
              decision_interval=.75,                 # 1 sec
              center_link_mass = None,             # None
              outer_link_mass = None,              # None
              wheel_mass=None,                     # None
              rolling_friction = .001,             # .001
              lateral_fricition = .2,              # .2
              spinning_fricition = None,           # None
              friction_anchor=None,                # None
              wheel_restitution = 0,               # 0
              joint_limits = np.pi/3,)             # +- np.pi/3
                





















